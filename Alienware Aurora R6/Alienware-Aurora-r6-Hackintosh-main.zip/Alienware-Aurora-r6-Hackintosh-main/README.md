# Alienware-Aurora-r6-Hackintosh
Alienware Aurora r6 Hackintosh MacOS 10.15.7 with OpenCore 0.6.3

PC Model: Alienware Aurora R6 
CPU: i7 7700K @4.2GHz (OC Disable)
RAM:Crucial DDR4 3200 16GB x 2  @2133Mhz (XPM Disable, because R6 can not work under the situation with more than 2666Mhz)
SSD: WD SN750 1TB NVME
HDD: WD Blue 3TB 7K2
GPU: Sapphire RX580 8G 2304sp
Wireless&Bluetooth: BCM94360CS2 

Monitor model:
Samsung U28H75x 4K@ 1080p Hidpi
