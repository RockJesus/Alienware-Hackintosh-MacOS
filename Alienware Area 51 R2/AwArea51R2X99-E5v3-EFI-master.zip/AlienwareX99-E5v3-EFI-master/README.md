## 硬件信息

```
CPU: Intel Xeon E5-2687W v3
主板: Dell Alienware Area-51 R2 X99
内存: 海盗船DDR4 2400 8G * 4
显卡: 蓝宝石 (Sapphire) RX580 8G D5 超白金 极光特别版
硬盘: Intel 545s 512G SSD
```

## Todo

- ✔ macOS Catalina 10.15
- ✔ 声卡驱动
- ✖ 隔空投送
- ✖ 接力
- ✖ Apple Watch 解锁 Mac

## 感谢

- [AppleALC.kext](https://github.com/acidanthera/AppleALC) 声卡驱动
- [AppleIntelE1000e.kext](https://github.com/chris1111/AppleIntelE1000e) 网卡驱动
- [AtherosE2200Ethernet.kext](https://github.com/Mieze/AtherosE2200Ethernet) 网卡驱动


