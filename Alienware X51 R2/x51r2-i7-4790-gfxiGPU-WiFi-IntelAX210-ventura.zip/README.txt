Download:
https://github.com/acidanthera/OcBinaryData/archive/refs/heads/master.zip

Extract: master.zip
Move: Resources to EFI/OC/Resources

Download:
https://github.com/OpenIntelWireless/itlwm/releases/download/v2.2.0-alpha/AirportItlwm-Ventura-v2.2.0-DEBUG-alpha-ee56708.zip

Move: AirportItlwm.kext to EFI/OC/Kexts