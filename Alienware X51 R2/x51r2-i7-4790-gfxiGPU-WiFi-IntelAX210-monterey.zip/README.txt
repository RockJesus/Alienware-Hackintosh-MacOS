Download:
https://github.com/acidanthera/OcBinaryData/archive/refs/heads/master.zip

Extract: master.zip
Move: Resources to EFI/OC/Resources

Download:
https://github.com/OpenIntelWireless/itlwm/releases/download/v2.1.0/AirportItlwm_v2.1.0_stable_Monterey.kext.zip

Move: AirportItlwm.kext to EFI/OC/Kexts