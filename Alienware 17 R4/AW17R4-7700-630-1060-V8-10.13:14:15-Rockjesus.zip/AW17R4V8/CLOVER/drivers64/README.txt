EFI/CLOVER/drivers64 has been replaced by EFI/CLOVER/drivers/BIOS and You can remove it safely.
Starting from Clover r4983 Clovers loads drivers from new directories, however for retro compatibility search for the old drivers64 if the new path is missing.
Anyway only EFI/CLOVER/drivers/BIOS is updated by the package installer.
