# Alienware Aurora R7 - Hackintosh


## 

| -------- | Alienware Aurora R7                                                     |
| -------- | ------------------------------------------------------------ |
| OS | macOS Catalina 10.15.3                 |
| Processor  | 8th Generation Intel® Core™ i7-8700 - Coffee Lake                                   |
| Memory    | 48GB DDR4-2133MHz, 2x8GB, 2x16GB                                                       |
| Storage     | Samsung 970 Evo NVMe M.2 SSD 1TB                            |
| Graphics   | Saphire Nitro RX 580 - 8GB                          |                                            |                                            |
| Wi-Fi | DW1820A -  Part #: CN-08PKF4|

Everything working 100%

Open Core 0.5.6
