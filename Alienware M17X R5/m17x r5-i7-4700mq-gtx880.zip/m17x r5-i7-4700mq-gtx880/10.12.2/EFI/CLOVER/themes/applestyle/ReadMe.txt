This is a theme by Eps

This version of the theme has been optimised with the following changes:
- The device icons in the /icons folder with .icns extensions are all .png files.
- All other .png files, except the fonts files, background and screenshot have also been reduced.