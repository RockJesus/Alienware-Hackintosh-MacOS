#!/bin/bash
if [ "$USER" != 'root' ]; then
    echo 'You must run this script as root'
    echo -e "Try: \033[0;31;1msudo $0 $1\033[0m instead"
    exit 1
fi 
if [ "$1" == 'restore' ]; then
    echo 'Deleting script file...'
    rm /Library/LaunchDaemons/com.pcbeta.dvd.reset.plist
    echo 'Done!'
    exit 1
fi

if [ "$1" == 'help' ]; then
echo 'You must run this script as root'
echo 'You can restore the modify,try: \033[0;31;1msudo sh reset_dvd.sh restore\033[0m'
exit 1
fi

if [ "$1" != '' ]; then
    echo 'Unknown argument(s)'
    exit 1
fi
echo 'ImageMad.NS_Thy -- bbs.pcbeta.com'
echo 'copying files'
cp ./com.pcbeta.dvd.reset.plist /Library/LaunchDaemons/
chmod u+x /Library/LaunchDaemons/com.pcbeta.dvd.reset.plist
echo 'Done!'
echo -e "To retore the modify, try: \033[0;31;1msudo $0 restore\033[0m"
